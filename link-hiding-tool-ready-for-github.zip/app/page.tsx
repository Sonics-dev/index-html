"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Link2, Lock, Globe, Users, User } from "lucide-react"
import { StarField } from "@/components/star-field"

type LinkType = "private" | "all-site" | "group" | "profile"

export default function HomePage() {
  const [selectedType, setSelectedType] = useState<LinkType | null>(null)
  const [linkInput, setLinkInput] = useState("")
  const [generatedLink, setGeneratedLink] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  const handleTypeClick = (type: LinkType) => {
    setSelectedType(type === selectedType ? null : type)
  }

  const handleGenerate = async () => {
    if (!linkInput || !selectedType) return

    setIsGenerating(true)

    try {
      const response = await fetch(`https://is.gd/create.php?format=json&url=${encodeURIComponent(linkInput)}`)

      let shortUrl = linkInput // fallback to original link

      if (response.ok) {
        const data = await response.json()
        if (data.shorturl) {
          shortUrl = data.shorturl
        }
      }

      let finalMaskedLink = ""
      if (selectedType === "private") {
        finalMaskedLink = `[https://www.roblox.com/share?code=server&type=Server](${shortUrl})`
      } else if (selectedType === "all-site") {
        const privateLink = `[https://www.roblox.com/share?code=server&type=Server](${shortUrl})`
        const profileLink = `[https://www.roblox.com/users/profile](${shortUrl})`
        const groupLink = `[https://www.roblox.com/groups](${shortUrl})`
        finalMaskedLink = `${privateLink}\n\n${profileLink}\n\n${groupLink}`
      } else if (selectedType === "group") {
        finalMaskedLink = `[https://www.roblox.com/groups](${shortUrl})`
      } else if (selectedType === "profile") {
        finalMaskedLink = `[https://www.roblox.com/users/profile](${shortUrl})`
      }

      setGeneratedLink(finalMaskedLink)
    } catch (error) {
      console.error("Error generating short link:", error)
      let fallbackLink = ""
      if (selectedType === "private") {
        fallbackLink = `[https://www.roblox.com/share?code=server&type=Server](${linkInput})`
      } else if (selectedType === "all-site") {
        fallbackLink = `[https://www.roblox.com/share?code=server&type=Server](${linkInput})\n\n[https://www.roblox.com/users/profile](${linkInput})\n\n[https://www.roblox.com/groups](${linkInput})`
      } else if (selectedType === "group") {
        fallbackLink = `[https://www.roblox.com/groups](${linkInput})`
      } else if (selectedType === "profile") {
        fallbackLink = `[https://www.roblox.com/users/profile](${linkInput})`
      }
      setGeneratedLink(fallbackLink)
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = () => {
    if (generatedLink) {
      navigator.clipboard.writeText(generatedLink)
    }
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <StarField />

      <a
        href="https://discord.gg/T7y2PSwfuE"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed top-4 right-4 z-50 bg-[#5865F2] hover:bg-[#4752C4] text-white rounded-full p-3 shadow-2xl transition-all hover:scale-110 group"
        aria-label="Join Discord"
      >
        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.077.077 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z" />
        </svg>
      </a>

      <div className="relative z-10">
        {/* Header */}
        <header className="flex items-center justify-center px-4 py-4">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-wider text-foreground">S O N I C ' S</h1>
        </header>

        {/* Main Content */}
        <main className="flex items-center justify-center px-4 py-6 sm:py-12">
          <div className="w-full max-w-2xl">
            <div className="bg-card/80 backdrop-blur-md rounded-3xl border border-border/50 p-5 sm:p-8 shadow-2xl">
              {/* Icon */}
              <div className="flex justify-center mb-5">
                <div className="bg-secondary/50 rounded-3xl p-5 border border-border/50">
                  <Link2 className="h-8 w-8 sm:h-10 sm:w-10 text-foreground" />
                </div>
              </div>

              {/* Title */}
              <h2 className="text-2xl sm:text-3xl font-bold text-center mb-2 sm:mb-3 text-foreground text-balance">
                HIDE YOUR LINKS
              </h2>

              <p className="text-sm sm:text-base text-center text-muted-foreground mb-6 sm:mb-8 text-pretty">
                Securely mask your destination URLs
              </p>

              {/* Button Grid */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6 sm:mb-8">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleTypeClick("private")}
                  className={`rounded-2xl h-12 sm:h-14 text-sm sm:text-base font-medium border-border/50 transition-all flex items-center justify-center ${
                    selectedType === "private"
                      ? "bg-primary/20 border-primary text-foreground"
                      : "bg-secondary/30 hover:bg-secondary/50 text-foreground"
                  }`}
                >
                  <Lock className="mr-1.5 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                  <span className="text-xs sm:text-base">Private Server</span>
                </Button>

                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleTypeClick("all-site")}
                  className={`rounded-2xl h-12 sm:h-14 text-sm sm:text-base font-medium border-border/50 transition-all flex items-center justify-center ${
                    selectedType === "all-site"
                      ? "bg-primary/20 border-primary text-foreground"
                      : "bg-secondary/30 hover:bg-secondary/50 text-foreground"
                  }`}
                >
                  <Globe className="mr-1.5 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                  <span className="text-xs sm:text-base">All Site</span>
                </Button>

                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleTypeClick("group")}
                  className={`rounded-2xl h-12 sm:h-14 text-sm sm:text-base font-medium border-border/50 transition-all flex items-center justify-center ${
                    selectedType === "group"
                      ? "bg-primary/20 border-primary text-foreground"
                      : "bg-secondary/30 hover:bg-secondary/50 text-foreground"
                  }`}
                >
                  <Users className="mr-1.5 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                  <span className="text-xs sm:text-base">Group</span>
                </Button>

                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => handleTypeClick("profile")}
                  className={`rounded-2xl h-12 sm:h-14 text-sm sm:text-base font-medium border-border/50 transition-all flex items-center justify-center ${
                    selectedType === "profile"
                      ? "bg-primary/20 border-primary text-foreground"
                      : "bg-secondary/30 hover:bg-secondary/50 text-foreground"
                  }`}
                >
                  <User className="mr-1.5 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                  <span className="text-xs sm:text-base">Profile</span>
                </Button>
              </div>

              {/* Input Section */}
              <div className="space-y-2.5 sm:space-y-3 mb-5 sm:mb-6">
                <label className="flex items-center text-xs sm:text-sm font-semibold text-foreground tracking-wide">
                  <Link2 className="mr-2 h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  ENTER LINK BOX
                </label>
                <Input
                  type="url"
                  placeholder="PUT YOUR FAKE LINK HERE..."
                  value={linkInput}
                  onChange={(e) => setLinkInput(e.target.value)}
                  className="h-12 sm:h-14 rounded-2xl bg-input border-border/50 text-foreground placeholder:text-muted-foreground text-sm sm:text-base"
                />
              </div>

              {/* Generate Button */}
              <Button
                size="lg"
                onClick={handleGenerate}
                disabled={!linkInput || !selectedType || isGenerating}
                className="w-full h-12 sm:h-14 rounded-2xl text-base sm:text-lg font-bold bg-foreground text-background hover:bg-foreground/90 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGenerating ? (
                  "GENERATING..."
                ) : (
                  <>
                    GENERATE
                    <Link2 className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                  </>
                )}
              </Button>

              {/* Generated Link Display */}
              {generatedLink && (
                <div className="mt-5 sm:mt-6 p-3 sm:p-4 bg-primary/10 border border-primary/30 rounded-2xl">
                  <p className="text-xs text-muted-foreground mb-2 font-medium">Generated Link:</p>
                  <div className="flex items-start gap-2">
                    <pre className="flex-1 text-xs sm:text-sm text-foreground font-mono break-all whitespace-pre-wrap">
                      {generatedLink}
                    </pre>
                    <Button
                      size="sm"
                      onClick={copyToClipboard}
                      className="rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shrink-0 h-8 text-xs"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
